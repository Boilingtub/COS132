#include <iostream>

using namespace std;

int main(){
    std::cout << "Hello, my name is u23694956. Welcome to Code Brew.\nHow can I help you today?";
}
