#include "Maths.h"
#include "Advanced_Maths.h"
#include <iostream>
using namespace std;

int main(){
    cout<<"###"<<endl;
    cout<< areaOfCircle(12.2) << endl;
    cout<< sum(2.3,3.7) << endl;
    cout<<"###"<<endl;
    return 0;
}