#ifndef Constants_h
#define Constants_h

const float PI = 3.14;

#endif