#include "Advanced_Maths.h"
#include "Constants.h"
#include <math.h>

float squareRoot(float x){
    return sqrt(x);
}

float areaOfCircle(float radius){
    return PI * radius * radius; 
}

float areaOfTriangle(float base, float height){
    return 0.5 * base * height;
}