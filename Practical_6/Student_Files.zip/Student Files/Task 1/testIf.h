#ifndef TEST_IF_H
#define TEST_IF_H

void checkEvenOrOdd(int number);
void checkWhereXRanks(int x, int y, int z);
void checkInRange(int x);

#endif