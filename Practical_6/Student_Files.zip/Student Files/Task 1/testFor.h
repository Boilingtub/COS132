#ifndef TEST_FOR_H
#define TEST_FOR_H

void testBasicFor(int upTo);

void testDoubleLoopVar(int x, int y);

void printOnlyEvenInLoop(int upTo);

void printPowers(int x, int upTo);


#endif