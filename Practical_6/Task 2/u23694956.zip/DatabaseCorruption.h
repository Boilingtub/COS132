#ifndef DATABASE_CORRUPTION_H
#define DATABASE_CORRUPTION_H
#include <iostream>
void corruptDatabase(int securityLevel);
void initiateCorruptionSequence();
void finalizeCorruption();
#endif // DATABASE_CORRUPTION_H
