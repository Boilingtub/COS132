#ifndef DATABASE_SEARCH_H
#define DATABASE_SEARCH_H
#include <iostream>
int searchDirectory();
int findDatabaseFile(int fileIndex);
int verifyDatabasePath(int dbIndex);
bool isPrime(int num);
#endif // DATABASE_SEARCH_H
