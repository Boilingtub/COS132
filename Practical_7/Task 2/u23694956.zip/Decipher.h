// Decipher.h
#ifndef DECIPHER_H
#define DECIPHER_H
#include <string>
using namespace std;
char shiftCharacter(char input, int shift);
string decipher(int num1, string str1, int num2, string str2);
#endif
