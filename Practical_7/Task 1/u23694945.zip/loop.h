#ifndef LOOP_H
#define LOOP_H

#include <iostream>
using namespace std;

void printCollatz(int num);
void printSquares(int n);
void printDiamond(int halfSize);

#endif