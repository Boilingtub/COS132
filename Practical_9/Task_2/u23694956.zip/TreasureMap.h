#ifndef TREASURE_MAP_H
#define TREASURE_MAP_H
#define ROWS 4
#define COLS 5
bool findTreasure(char map[ROWS][COLS], int jumps[], int jumpsLength, char *result);
#endif
