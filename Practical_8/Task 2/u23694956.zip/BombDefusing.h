#ifndef BOMB_DEFUSING_H
#define BOMB_DEFUSING_H

int calculateSize(int* arr);
void findPairs(int* arr, int size);
    void UT_findPairs();

#endif
