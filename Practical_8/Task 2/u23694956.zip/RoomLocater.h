#ifndef ROOM_LOCATER_H
#define ROOM_LOCATER_H
    
#include<iostream>

int substringSearch(const char* str, const char* substr);
    void UT_substrSearch();
void indexToChar(int index);

#endif //ROOM_LOCATER_H
