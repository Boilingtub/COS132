#ifndef TASK_1_H
#define TASK_1_H

#include <iostream>

void sortNumbers(int &a, int &b, int &c);
    void UT_sortNumbers();
void swap(int** ptrA, int** ptrB);
    void UT_swap();

#endif
