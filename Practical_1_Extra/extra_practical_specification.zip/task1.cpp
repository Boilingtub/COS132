#include <string>
#include <iostream>
using namespace std;

int main(){
    cout << "###" << endl;

    //add your code here


    cout << "###" << endl;
    return 0;
}