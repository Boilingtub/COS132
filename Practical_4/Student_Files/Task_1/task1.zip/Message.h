#ifndef MESSAGE_H
#define MESSAGE_H

void printPassMessage();
void printFailMessage();
void printDistrinction();
void handlePass(double);

#endif
